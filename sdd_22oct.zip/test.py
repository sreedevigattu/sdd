import categorize_nn
from pathlib import Path
import sys, os, datetime

def getf(path, option):
    global nfiles, ndirectories, nlevel
    files = os.listdir(path)
    folder = Path(path)
    for file in files:
        f = str(folder / file)
        if os.path.isdir(f):
            print(f, "is a directory")
            '''print("\t"*nlevel, f)
            ndirectories += 1 
            nlevel += 1'''
            getf(f, option)
        else:
            #nfiles += 1
            #print("\t"*nlevel,file)
            if option == 'scan':
                #text.getcorpus(path)
                text.readfromfile(f)
            elif option == 'categorize':
                print("Processing started for ", f)
                category = categorize_nn.predict(f)
                print(f, " --> ", category)
                resultfile.write(f + "," + category + "\n")

# python test.py 
path = sys.argv[1]
option = sys.argv[2]
if option == 'categorize':
    tic = datetime.datetime.now()
    resultfile = open("out" + tic.strftime("_%Y%m%d_%H%M")+ ".csv", "a")
    resultfile.write("file, category\n")
elif option == 'scan':
    import text
getf(path, option)
if option == 'categorize':
    resultfile.close()